package com.example.mohitbajaj_calculator;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Switch;

public class MainActivity extends AppCompatActivity {
    Boolean isnewop=true;
    EditText str1;
    String oldnumber;
    String newnumber;
    String op="0";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        str1=findViewById(R.id.val);

    }

    public void numberEvent(View view) {
        if(isnewop)
        {
            str1.setText("");
        }
        isnewop=false;
        String num=str1.getText().toString();
        switch(view.getId())
        {
            case R.id.zero:
                num+="0";
                break;
            case R.id.one:
                num+="1";
                break;
            case R.id.two:
                num+="2"; break;
            case R.id.three:
                num+="3"; break;
            case R.id.four:
                num+="4"; break;
            case R.id.five:
                num+="5"; break;
            case R.id.six:
                num+="6"; break;
            case R.id.seven:
                num+="7"; break;
            case R.id.eight:
                num+="8"; break;
            case R.id.nine:
                num+="9"; break;
            case R.id.dot:
                num+=".";
                break;
            case R.id.sign:
                num="-"+num;
                break;

        }
        str1.setText(num);
    }

    public void operatorEvent(View view) {
        oldnumber=str1.getText().toString();
        op="";
        switch(view.getId())
        {
            case R.id.plus:
                op="+";
                break;
            case R.id.minus:
                op="-";
                break;
            case R.id.mul:
                op="*";
                break;
            case R.id.divide:
                op="/";
                break;
        }
        //String temp=oldnumber+op;
        //str1.setText(temp);
        isnewop=true;
    }

    public void equalEvent(View view) {
    newnumber=str1.getText().toString();
    int ans=0;
        switch(op)
        {
            case "+":
                ans=Integer.parseInt(oldnumber)+Integer.parseInt(newnumber);
                break;
            case "-":
                ans=Integer.parseInt(oldnumber)-Integer.parseInt(newnumber);
                break;
            case "*":
                ans=Integer.parseInt(oldnumber)*Integer.parseInt(newnumber);
                break;
            case "/":
                ans=Integer.parseInt(oldnumber)/Integer.parseInt(newnumber);
                break;
        }
        str1.setText(Integer.toString(ans));
        isnewop=true;
    }

    public void acEvent(View view) {
        str1.setText("0");
        isnewop=true;
    }

    public void percentEvent(View view) {
        double num=Double.parseDouble(str1.getText().toString())/100;
        str1.setText(Double.toString(num));
        isnewop=true;
    }
}