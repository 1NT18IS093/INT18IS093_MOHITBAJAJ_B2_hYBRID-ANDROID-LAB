package com.example.mohitbajaj_app2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Toast.makeText(getApplicationContext(), "", Toast.LENGTH_SHORT).show();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button mybutton=findViewById(R.id.sum);
        mybutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Toast.makeText(getApplicationContext(), "Here is your result", Toast.LENGTH_SHORT).show();
                EditText numa=findViewById(R.id.a);
                EditText numb=findViewById(R.id.b);
                int a=Integer.parseInt(numa.getText().toString());
                int b=Integer.parseInt(numb.getText().toString());
                int c=a+b;
                Intent it=new Intent(getApplicationContext(),result.class);
                it.putExtra("sum",Integer.toString(c));
               // it.putExtra()
                startActivity(it);

            }
        });

        Toast.makeText(getApplicationContext(), "Activity started", Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onResume() {
        super.onResume();

            Toast.makeText(getApplicationContext(), "App Started again", Toast.LENGTH_SHORT).show();
        }


    @Override
    protected void onStart() {
        super.onStart();
        Toast.makeText(getApplicationContext(), "App Started again", Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onPause() {
        super.onPause();
        Toast.makeText(getApplicationContext(), "App minimized", Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Toast.makeText(getApplicationContext(), "App closed", Toast.LENGTH_SHORT).show();
    }
}