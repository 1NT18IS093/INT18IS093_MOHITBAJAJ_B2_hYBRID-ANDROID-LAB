package com.example.sqlite_1nt18is093;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button insert,update,delete,view;
    EditText name,contact,age;
    DBhelper db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        insert=findViewById(R.id.Insert);
        update=findViewById(R.id.Update);
        delete=findViewById(R.id.Delete);
        view=findViewById(R.id.View);
        name=findViewById(R.id.Name);
        contact=findViewById(R.id.Contact);
        age=findViewById(R.id.Age);
        db=new DBhelper(this);
        insert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String nametxt=name.getText().toString();
                String contxt=contact.getText().toString();
                String agetxt=age.getText().toString();
                boolean status=db.insert(nametxt,contxt,agetxt);
                if (status)
                {
                    Toast.makeText(MainActivity.this, "successful", Toast.LENGTH_SHORT).show();
                }
                else{
                    Toast.makeText(MainActivity.this, "unsuccessful", Toast.LENGTH_SHORT);
                }
            }
        });
        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String nametxt=name.getText().toString();
                String contxt=contact.getText().toString();
                String agetxt=age.getText().toString();
                boolean status=db.update(nametxt,contxt,agetxt);
                if (status)
                {
                    Toast.makeText(MainActivity.this, "update successful", Toast.LENGTH_SHORT).show();
                }
                else{
                    Toast.makeText(MainActivity.this, "update unsuccessful", Toast.LENGTH_SHORT);
                }
            }
        });
        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String nametxt=name.getText().toString();
//                String contxt=contact.getText().toString();
//                String agetxt=age.getText().toString();
                boolean status=db.delete(nametxt);
                if (status)
                {
                    Toast.makeText(MainActivity.this, "delete successful", Toast.LENGTH_SHORT).show();
                }
                else{
                    Toast.makeText(MainActivity.this, "delete unsuccessful", Toast.LENGTH_SHORT);
                }
            }
        });
        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Cursor res = db.viewData();
                if (res.getCount() == 0)
                    Toast.makeText(MainActivity.this, "No Record Exist", Toast.LENGTH_SHORT).show();
                else {
                    StringBuffer buffer = new StringBuffer();
                    while (res.moveToNext()) {
                        buffer.append("Name :" + res.getString(0) + "\n");
                        buffer.append("Contact :" + res.getString(1) + "\n");
                        buffer.append("Age :" + res.getString(2) + "\n");
                    }
                    AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                    builder.setCancelable(true);
                    builder.setTitle("User Data");
                    builder.setMessage(buffer.toString());
                    builder.show();
                }
            }
        });


    }
}
