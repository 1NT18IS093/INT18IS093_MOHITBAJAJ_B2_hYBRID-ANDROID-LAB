package com.example.sqlite_1nt18is093;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DBhelper extends SQLiteOpenHelper {


    public DBhelper(@Nullable Context context) {
        super(context, "Userdata.db", null, 1);
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create Table Userdetails(name TEXT primary key, contact TEXT, age TEXT)");
    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldversion, int newversion) {
        db.execSQL("drop Table if exists Userdetails");
    }
    public boolean insert(String nametxt, String contxt, String agetxt) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("name",nametxt);
        contentValues.put("contact",contxt);
        contentValues.put("age",agetxt);
        long result=db.insert("Userdetails", null, contentValues);
        if(result==-1)
            return false;
        else
            return true;
    }

    public boolean update(String nametxt, String contxt, String agetxt) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("contact",contxt);
        contentValues.put("age",agetxt);
        Cursor cursor = db.rawQuery("Select * from Userdetails where name = ?", new String[] {nametxt});
        if(cursor.getCount() > 0) {
            long result = db.update("Userdetails", contentValues, "name=?", new String[] {nametxt});
            if (result == -1)
                return false;
            else
                return true;
        } else {
            return false;
        }
    }

    public boolean delete(String nametxt) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        Cursor cursor = db.rawQuery("Select * from Userdetails where name = ?", new String[] {nametxt});
        if(cursor.getCount() > 0) {
            long result = db.delete("Userdetails", "name=?", new String[] {nametxt});
            if (result == -1)
                return false;
            else
                return true;
        } else {
            return false;
        }
    }
    public Cursor viewData () {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("Select * from Userdetails", null);
        return cursor;
    }





}
